#ifndef MSR_TOOLS_VERSION_H
#define MSR_TOOLS_VERSION_H
#define VERSION_STRING "msr-tools-1.3"
#endif
